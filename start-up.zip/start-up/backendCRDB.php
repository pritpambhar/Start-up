<?php
    include("sidebar.html");
?>
<?php
    $server = "localhost";
    $username = "root";
    $con = mysqli_connect($server, $username, "");
    mysqli_select_db($con,"account_esta");
?>
<?php
     if(isset($_POST["add-debit"]))
     {
        $transaction=mysqli_query($con,"insert into transaction_master (customer_id,transaction_date,credit) values ('".$_POST["id"]."',CURDATE(),'".$_POST["credit_amt"]."')");
        echo $transaction."";
        //header("location:test.php");
     }
?>