<?php
    include("includes/sidebar.php");
?>
<html>
<head>
<title>Sachin Enterprise</title>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<style>
        .common
        {
                width:300px;
                height:100px;
                margin-left:-200px;
        }
        body
        {
                background-image:url("images/bg.jpg");
                background-repeat:no-repeat;
                background-size:cover;
        }
</style>
<head>
<body>
<div style="margin-left:40%;margin-top:3%;">

<form method="post" action="billGeneration.php">
        <button type="submit" class="btn btn-warning common"><h3>Bill Generation</h3></button>
</form>
<br>
<form method="post" action="monthlyHistory.php">
        <button type="submit" class="btn btn-success common"><h3>Monthly History</h3></button>
</form>
<br>
<form method="post" action="customerHistory.php">
        <button type="submit" class="btn btn-danger common"><h3>Customer History</h3></button>
</form>
<br>
<form method="post" action="addCredit.php">
        <button type="submit" class="btn btn-primary common"><h3>Add Credit</h3></button>
</form>
<br>
</div>
<body>
<html>