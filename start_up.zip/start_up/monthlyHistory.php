<?php
    include("includes/sidebar.php");
?>
<html>
	<head>
    	<title>History</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	</head>
	<body>
		<div class="container">
        
            <!--nav bar-->
				<div class="row" style="margin-top:30px">
					<div class="col-lg-8 col-lg-offset-2">
						<ul class="nav nav-tabs">
						  <li id="contact-b" class="active"><a href="#contact">History</a></li>
						</ul>
					</div>
				</div>
				<br/>
				<br/>
                
				<div class="row">
					<div id="contact" class="col-lg-6 col-lg-offset-3">
						<form method="post" action="monthlyHistoryPreview.php">
						  
                          <div class="form-group">
							<label><h3>From</h3></label>
							<input type="date" name="from" class="form-control" required>
                          </div>

                          <div class="form-group">
							<label><h3>To</h3></label>
							<input type="date" name="to" class="form-control" required>
                          </div>
                            <br>
                          <button type="submit" name="fetch-history" class="btn btn-success">Show History</button>
                        
                        </form>
                    </div>
				</div>
		    </div>
	</body>
</html>