<?php
    include("includes/sidebar.php");
?>
<?php
    $server = "localhost";
    $username = "root";
    $con = mysqli_connect($server, $username, "");
    mysqli_select_db($con,"account_esta");
    $customer=mysqli_query($con,"select * from customer_master where customer_name='".$_POST["name"]."'");
    $customer_fetch=mysqli_fetch_assoc($customer);
    $customer_id=$customer_fetch["customer_id"];
    //echo $customer_id;
?>
<html>

<head>
    <title>Sachin Enterprise</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
</head>

<body>
    <form method="post" action="backend/addCredit.php">
        <!-- <h3><u>Vendor Details</u></h3>
                        <br> -->
        <div class="form-group">
            <label>Enter Credit</label>
            <input type="text" name="credit_amt" class="form-control">
        </div>

        <input type="hidden" name="id" value=<?php echo $customer_id ;?>>

        <button type="submit" name="add-debit" class="btn btn-success">Add Credit</button>
    </form>
</body>

</html>