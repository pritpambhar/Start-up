<html>
	<head>
    	<title>Contact Us</title>
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	</head>
	<body>
		<div class="container">
        
        <!--nav bar-->
				<div class="row" style="margin-top:30px">
					<div class="col-lg-8 col-lg-offset-2">
						<ul class="nav nav-tabs">
						  <li id="contact-b"><a href="#contact">Registration</a></li>
						</ul>
					</div>
				</div>
				<br/>
				<br/>
                
				<!-- email form -->
				<div class="row">
					<div id="contact" class="col-lg-6 col-lg-offset-3">
						<form method="post">
                          <div class="form-group">
							<label>Full Name</label>
							<input type="text" name="name" class="form-control" placeholder="name" required>
						  </div>
                          <div class="form-group">
							<label>No. of Items</label>
							<input type="number" id="number" name="number" class="form-control" placeholder="number" required>
						  </div>
                          <button type="submit" id="done" name="done" class="btn btn-default" onclick="product()">Add Items</button>
                          <!--  <br>
                            <br>
                            <br>   
                            <h2>Product Details</h2>
                            <br>
                          <div class="form-group">
							<label>Product name</label>
							<input type="number" name="number" class="form-control" placeholder="number" required>
						  </div>
                          <div class="form-group">
							<label>QTY</label>
							<input type="number" name="number" class="form-control" placeholder="number" required>
						  </div>
                          <div class="form-group">
							<label>Price</label>
							<input type="number" name="number" class="form-control" placeholder="number" required>
                          </div> -->
                          <div id="one">
                          </div> 
                          <br>
                          <button type="submit" name="submit" class="btn btn-default">Register</button>

						</form>
					</div>
				</div>
		</div>
        <script>
            function product()
            {
                var n=document.getElementById("number").value;
                //alert(n);
                for (var i = 0; i < n; i++)
                {
                    document.getElementById("one").innerHTML += " <br><h2>Product Details</h2><br><div class='form-group'><label>Product name</label><input type='number' name='number' class='form-control' placeholder='number' required></div><div class='form-group'><label>QTY</label><input type='number' name='number' class='form-control' placeholder='number' required></div><div class='form-group'><label>Price</label><input type='number' name='number' class='form-control' placeholder='number' required></div>";               
                }
            }
        </script>
	</body>
</html>