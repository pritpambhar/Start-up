<?php
    $server = "localhost";
    $username = "root";
    $con = mysqli_connect($server, $username, "");
    mysqli_select_db($con,"account_esta");

    $bill_history=mysqli_query($con,"select * from customer_bill_history");
    
    $customer=mysqli_query($con,"select * from customer_master");
    
    $customer_id_fetch=mysqli_query($con,"select customer_id from customer_master where customer_name='".$_POST["name"]."'");
    $customer_id_row=mysqli_fetch_assoc($customer_id_fetch);
    $customer_id=$customer_id_row["customer_id"];

    $invoice=mysqli_query($con,"SELECT transaction_date as date,invoice_id as invoice_id,credit as credit,null as debit FROM transaction_master
    where customer_id=".$customer_id."
    UNION ALL
    SELECT invoice_date as date,invoice_id as invoice_id,null as credit,debit as debit FROM invoice_master
    WHERE customer_id=".$customer_id."
    ORDER BY date ASC");
?>
<html>
<head>
	<title>Custmer History</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
    <h1 align="center"><?php echo $_POST["name"]; ?></h1>
    <br>
    <table class="table table-bordered">
        <tr>
            <td><b>Date</b></td>
            <td><b>op. Balance</b></td>
            <td><b>Invoice Id</b></td>
            <td><b>credit</b></td>
            <td><b>debit</b></td>
            <td><b>closing</b></td>
        </tr>
        
        <?php 
        $closing=0;
        while($rs=mysqli_fetch_assoc($invoice))
        { 
            $closing = $closing + $rs["debit"] ;    
        ?> 
        <tr>
            <td><?php echo $rs["date"]; ?></td>
            <td><?php echo "0.0"; ?></td>
            <td><?php echo $rs["invoice_id"]; ?></td>
            <td><?php echo $rs["credit"]; ?></td>
            <td><?php echo $rs["debit"]; ?></td>
            <td><?php echo $closing-$rs["credit"]; ?></td>
        </tr>
    <?php
        } 
     ?>
     </table>
</body>
</html>     