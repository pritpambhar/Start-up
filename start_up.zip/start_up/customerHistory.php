<?php
    include("includes/sidebar.php");
?>
<?php
    $server = "localhost";
    $username = "root";
    $con = mysqli_connect($server, $username, "");
    mysqli_select_db($con,"account_esta");
    $customer=mysqli_query($con,"select * from customer_master");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Custmer History</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

</head>
<body>
<div class="container">
         
        <!--nav bar-->
				<div class="row" style="margin-top:30px">
					<div class="col-lg-8 col-lg-offset-2">
						<ul class="nav nav-tabs">
						  <li id="contact-b"><a href="#contact">Customer History</a></li>
						</ul>
					</div>
				</div>
				<br/>
				<br/>
                
				<div class="row">
					<div id="contact" class="col-lg-6 col-lg-offset-3">
                        <form name="" method="post" action="customerHistoryPreview.php">
                        <div class="form-group">
                            <select name="name" class="form-control">
                               
                                <?php
                                    while($rs=mysqli_fetch_assoc($customer))
                                    {
                                    ?><option class="form-control" value="<?php echo $rs["customer_name"]; ?>"><?php echo $rs["customer_name"]; ?></option>
                                <?php }
                                    ?>
                                
                            </select>
                        </div>
                            
                        <button type="submit" name="submit" class="btn btn-default">submit</button>
                        </form>
                        <br>
                        <br>
                     </div>
           </div>
        </div>
</body>
</html>